from view.CLI import CLI

if __name__ == "__main__":
    CLI().run()













